﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using betterExamGameJam;
using betterExamGameJam.Actors;
using betterExamGameJam.Actors.PokeDex;
using betterExamGameJam.Actors.Moves;

namespace betterExamGameJam
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        private void App_OnStartup(object sender, StartupEventArgs e)
        {
                
            // Instanciate the view you want to display and show it
            MainWindow mainWindow = new MainWindow();
            mainWindow.ShowDialog();
        }
    }
}
