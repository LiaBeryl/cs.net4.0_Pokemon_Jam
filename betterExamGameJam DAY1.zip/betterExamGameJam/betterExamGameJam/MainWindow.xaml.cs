﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using betterExamGameJam;
using betterExamGameJam.Actors;
using betterExamGameJam.Actors.Moves;
using betterExamGameJam.Actors.PokeDex;

namespace betterExamGameJam
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            this.DataContext = WindowManager.Instance;
            GameLoop();
        }

        void GameLoop()
        {
            Party.Instance.AddToParty(new Dex0()); // get starter

            while (this.IsLoaded)
            {
                if (WindowManager.Instance.newMove)
                {
                    Window1 learn = new Window1();
                    WindowManager.Instance.newMove = false;
                    learn.ShowDialog();
                }
            }
        }

        private void PartyMemberEvent(object sender, RoutedEventArgs e)
        {
            Party.Instance.NextPartyMember();
        }
    }
}
