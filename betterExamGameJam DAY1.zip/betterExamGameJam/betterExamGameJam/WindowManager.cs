﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam
{
    class WindowManager
    {
        public static WindowManager Instance;
        public bool newMove;
        public string newMoveName = "";

        static WindowManager()
        {
            Instance = new WindowManager();
        }

        public Actors.Pokemon PartyMember
        {
            get { return Party.Instance.GetActivePartyMember(); }
        }

        public String NewMoveName
        {
            get{ return newMoveName; }
            set { newMoveName = value; }
        }

        public Actors.Move GetMove0
        {
            get { return PartyMember.GetMove(0); }
        }

        public Actors.Move GetMove1
        {
            get {return PartyMember.GetMove(1); }
        }

        public Actors.Move GetMove2
        {
            get { return PartyMember.GetMove(2); }
        }

        public Actors.Move GetMove3
        {
            get { return PartyMember.GetMove(3); }
        }
    }
}
