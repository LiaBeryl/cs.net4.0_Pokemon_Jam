﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam
{
    class Party
    {
        public static Party Instance;
        List<Actors.Pokemon> party = new List<Actors.Pokemon>();
        int activePartyIndex;

        static Party()
        {
            Instance = new Party();
            Instance.activePartyIndex = 0;
        }

        public Actors.Pokemon GetActivePartyMember()
        {
            return Instance.party.ElementAt(Instance.activePartyIndex);
        }

        public void NextPartyMember()
        {
            if (activePartyIndex < Instance.party.Count)
            {
                activePartyIndex += 1;
            }else
            {
                activePartyIndex = 0;
            }
        }

        public void AddToParty(Actors.Pokemon target)
        {
            party.Add(target);
        }
    }
}
