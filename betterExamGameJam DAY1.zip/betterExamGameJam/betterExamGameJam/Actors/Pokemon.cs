﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    abstract class Pokemon
    {
        public int dexNum;
        public string name;
        public Ability ability; //not a feature as of yet strech
        public List<Stat> stats = new List<Stat>();
        public List<Move> moves = new List<Move>();
        public float level;
        public KeyValuePair<Type.Types,Type.Types> type;
        protected Learnset lvUpMoves = new Learnset();

        public Pokemon(int dn)
        {
            dexNum = dn;
            level = 0f;
            for(int i=0; i<4; ++i)
            {
                moves.Add(new Moves.NullMove(this));
            }
            InitLearnset();
            ForceLevelUp();
        }

        public Pokemon(int dn, float lv)
        {
            dexNum = dn;
            level = 0f;
            InitLearnset();
            float l = (float)Math.Floor(lv);
            for(float F=0f; F<=l; F+=1)
            {
                ForceLevelUp();
            }
        }

        public string Name
        {
            get { return name; }
        }

        public string Ability
        {
            get { return ability.name; }
        }

        public string Type
        {
            get { return type.ToString(); }
        }

        public string Level
        {
            get { return level.ToString(); }
        }

        public string DexNum
        {
            get { return dexNum.ToString(); }
        }

        protected abstract void InitLearnset();

        public Stat GetStat(Stat.StatName whatWeWant)
        {
            foreach(Stat s in stats)
            {
                if (s.name == whatWeWant)
                {
                    return s;
                }
            }
            throw new System.InvalidOperationException("Stat not found on pokemon, may not be initialized properly.");
        }

        public Move GetMove(int moveIndex)
        {
            return moves.ElementAt(moveIndex);
        }

        public void InitBaseStats(int hp, int attack, int defence, int spattack, int spdefence, int speed)
        {
            stats.Add(new Stat(Stat.StatName.HP, hp));
            stats.Add(new Stat(Stat.StatName.Attack, attack));
            stats.Add(new Stat(Stat.StatName.Defense, defence));
            stats.Add(new Stat(Stat.StatName.SpAttack, spattack));
            stats.Add(new Stat(Stat.StatName.SpDefense, spdefence));
            stats.Add(new Stat(Stat.StatName.Speed, speed));
        }

        protected void LevelUp()
        {
            level += 1;
            foreach(KeyValuePair<int, Move> k in lvUpMoves)
            {
                if (k.Key == (int)Math.Floor(level))
                {
                    AskLearnMove(k.Value);
                }
            }
            return;
        }

        protected void ForceLevelUp()
        {
            Random rand = new Random();
            level += 1;
            foreach (KeyValuePair<int, Move> k in lvUpMoves)
            {
                if (k.Key == (int)Math.Floor(level))
                {
                    LearnMove(rand.Next(0,4), k.Value);
                }
            }
            return;
        }

        public void UseMove(int slotNum, Pokemon target)  //target gets assigned in the battle manager (not yet made)
        {
            moves.ElementAt(slotNum).SendAttack(target);
        }

        private void AskLearnMove(Move newMove)
        {
            WindowManager.Instance.NewMoveName = newMove.Name;
            WindowManager.Instance.newMove = true;
        }

        public void LearnMove(int i, Move m)
        {
            if (i >= 0 && i < 4)
            {
                moves.RemoveAt(i);
                moves.Insert(i, m);
            }
        }

        public void GotHit(int damage)
        {
            //do contact stuffs if that matters
            ApplyHPChange(damage);
        }

        protected void ApplyHPChange(int change)
        {
            if (change > 0)
            {
                //send damage msg
            } else if(change < 0)
            {
                //send heal msg
            }else if(change == 0)
            {
                //send noting happened msg
            }
            
        }
    }
}
