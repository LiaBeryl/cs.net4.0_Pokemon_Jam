﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    

    abstract class Move
    {
        public enum MoveStyle { physical, special, status }

        Random rand;
        Pokemon actor;
        bool STAB;
        protected Type.Types type;
        public float damageValue;
        protected MoveStyle moveStyle;
        protected string name;
        protected int pp;
        protected float accuracy;
        public abstract void Attack(Pokemon target);

        protected Move(Pokemon a)
        {
            actor = a;
            if (actor.type.Key == type||actor.type.Value==type) { STAB = true; } else { STAB = false; }
            rand = new Random();
        }

        public string Name
        {
            get {return name; }
        }

        public string MoveType
        {
            get { return type.ToString(); }
        }

        public string Style 
        {
            get { return moveStyle.ToString(); }
        }

        public string Value
        {
            get { return damageValue.ToString()+" Power"; }
        }

        public void SendAttack(Pokemon target)
        {
            Attack(target);
            PPDown(1);
        }

        private void PPDown(int dropAmount)
        {
            pp -= dropAmount;
            if (pp < 0) { pp = 0; }
        }

        protected int DamageCalc(Pokemon target, MoveStyle physOrSpec)
        {
            //add status and healing streach
            if (damageValue > 0)
            {
                float randVal = rand.Next(85, 101) / 100f;
                if (physOrSpec == MoveStyle.physical)
                {
                    return (int)Math.Ceiling(((2f * actor.level / 5f + 2f) * damageValue * actor.GetStat(Stat.StatName.Attack).value / target.GetStat(Stat.StatName.Defense).value) / 50f + 2f * randVal * GetSTABMult());
                }
                else if (physOrSpec == MoveStyle.special)
                {
                    return (int)Math.Ceiling(((2f * actor.level / 5f + 2f) * damageValue * actor.GetStat(Stat.StatName.SpAttack).value / target.GetStat(Stat.StatName.SpDefense).value) / 50f + 2f * randVal * GetSTABMult());
                }
            }
            throw new InvalidOperationException("DamageCalc was called for a non-damaging move, what do you think you are doing?!");
        }
        
        float GetSTABMult()
        {
            if (STAB)
            {
                return 1.5f;
            }
            else
            {
                return 1.0f;
            }
        }
    }
}
