﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.PokeDex
{
    class Dex0 : Pokemon
    {
        public Dex0(): base(0)
        {
            InitBaseStats(33, 136, 0, 6, 6, 29);
            type = new KeyValuePair<Type.Types, Type.Types>(Actors.Type.Types.Normal, Actors.Type.Types.Null);
            ability = new Actors.Abilities.NullAbility();
            name = "MissingNo";
        }

        public Dex0(float lv) : base(0, lv)
        {
            InitBaseStats(33, 136, 0, 6, 6, 29);
            LearnMove(0, new Moves.Tackle(this));
            type = new KeyValuePair<Type.Types, Type.Types>(Actors.Type.Types.Normal, Actors.Type.Types.Null);
            ability = new Actors.Abilities.NullAbility();
            name = "MissingNo";
        }

        protected override void InitLearnset()
        {
            lvUpMoves.Add(new KeyValuePair<int, Move>(1, new Actors.Moves.WaterGun(this)));
            lvUpMoves.Add(new KeyValuePair<int, Move>(1, new Actors.Moves.WaterGun(this)));
            lvUpMoves.Add(new KeyValuePair<int, Move>(1, new Actors.Moves.SkyAttack(this)));
        }
    }
}
