﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    class Learnset : List<KeyValuePair<int, Move>>
    {
        public new bool Add(KeyValuePair<int, Move> a)  
        {
            foreach(KeyValuePair<int, Move> l in this)
            {
                if(l.Key == a.Key && l.Value == a.Value)
                {
                    return false;
                }
            }
            base.Add(a);
            return true;
        }
    }
}
