﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Abilities
{
    class NullAbility :Ability
    {
        public NullAbility() : base()
        {
            name = "null";
        }
    }
}
