﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    class Stat
    {
        public enum StatName { HP, Attack, Defense, SpAttack, SpDefense, Speed}
        public StatName name;
        public float value;
        public Stat(StatName n, float v)
        {
            name = n;
            value = v;
        }
    }
}
