﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Moves
{
    class WaterGun : Move
    {
        public WaterGun(Pokemon a) : base(a)
        {
            name = "Water Gun";
            damageValue = 40;
            pp = 25;
            moveStyle = MoveStyle.special;
            type = Type.Types.Water;
        }

        public override void Attack(Pokemon target)
        {
            target.GotHit(DamageCalc(target, moveStyle));
        }
    }
}
