﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Moves
{
    class SkyAttack :Move
    {
        public SkyAttack(Pokemon a) : base(a)
        {
            name = "Sky Attack";
            damageValue = 200;
            pp = 5;
            moveStyle = MoveStyle.physical;
            type = Type.Types.Water;
        }

        public override void Attack(Pokemon target)
        {
            //this is a 2 turn atack and needs a working battle flow manager before implementation
            //target.GotHit(DamageCalc(target, moveStyle));
        }
    }
}
