﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Moves
{
    class NullMove : Move
    {
        public NullMove(Pokemon a) : base(a)
        {
            name = "Null";
            damageValue = 0;
            moveStyle = MoveStyle.status;
            type = Type.Types.Null;
        }

        public override void Attack(Pokemon target)
        {
            target.GotHit(DamageCalc(target, moveStyle));
        }
    }
}
