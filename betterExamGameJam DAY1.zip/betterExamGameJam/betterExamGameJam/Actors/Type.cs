﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    class Type
    {
        public enum Types
        {
            Null,
            Normal,
            Fire,
            Fighting,
            Water,
            Flying,
            Grass,
            Poison,
            Electric,
            Ground,
            Psychic,
            Rock,
            Ice,
            Bug,
            Dragon,
            Ghost,
            Dark,
            Steel,
            Fairy
        }
    }
}
