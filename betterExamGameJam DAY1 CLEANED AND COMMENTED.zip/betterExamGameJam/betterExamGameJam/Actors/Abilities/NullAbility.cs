﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Abilities
{
    /// <summary>
    /// another null for testing purposes
    /// </summary>
    class NullAbility :Ability //Lia
    {
        public NullAbility() : base()
        {
            name = "null";
        }
    }
}
