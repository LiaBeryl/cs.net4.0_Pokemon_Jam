﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    using LearnsetItem = KeyValuePair<int, Move>;//typing shortcut
    /// <summary>
    /// this class is just a clarity thing, I don't even know if it is needed.
    /// but hey, it might be useful idk
    /// It is supposed to be a designated container class for the learnset of a pokemon.
    /// </summary>
    class Learnset : List<LearnsetItem>  //Lia
    {
        public new bool Add(KeyValuePair<int, Move> a)  
        {
            foreach(KeyValuePair<int, Move> l in this)
            {
                if(l.Key == a.Key && l.Value == a.Value)
                {
                    return false;
                }
            }
            base.Add(a);
            return true;
        }
    }
}
