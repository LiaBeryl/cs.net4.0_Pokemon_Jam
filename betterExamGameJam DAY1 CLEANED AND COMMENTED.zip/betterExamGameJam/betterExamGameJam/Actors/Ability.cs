﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{    /// <summary>
    /// planed feature.  only reason it's here is so that the rest of the 
    /// archetecture can be built and not have to splice it in later.
    /// </summary>
    abstract class Ability //Lia
    {
        //strech goal
        public string name;
        public Ability()
        {
        }
    }
}
