﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Moves
{   /// <summary>
    /// an empty move to serve as a template/inital test site
    /// </summary>
    class NullMove : Move  //Lia
    {
        public NullMove(Pokemon a) : base(a)
        {
            name = "Null";
            damageValue = 0;
            moveStyle = MoveStyle.status;
            type = Type.Types.Null;
        }

        public override void Attack(Pokemon target)
        {
        }
    }
}
