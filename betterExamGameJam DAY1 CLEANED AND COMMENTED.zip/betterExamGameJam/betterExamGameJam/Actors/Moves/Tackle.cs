﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.Moves
{
    class Tackle: Move  //Lia
    {
        public Tackle(Pokemon a) : base(a)
        {
            name = "Tackle";
            damageValue = 40;
            pp = 35;
            moveStyle = MoveStyle.physical;
            type = Type.Types.Normal;
        }

        public override void Attack(Pokemon target)
        {
            target.GotHit(DamageCalc(target, moveStyle));
        }
    }
}
