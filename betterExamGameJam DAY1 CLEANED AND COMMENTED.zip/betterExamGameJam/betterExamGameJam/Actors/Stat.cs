﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{   /// <summary>
    /// the container for a statname and baseValue.  hopfuly it will be more in the future,
    /// and contain the equations for modifying stats by iv ev lv and nature, but those are not implemented yet.
    /// </summary>
    class Stat  //Lia
    {
        public enum StatName { HP, Attack, Defense, SpAttack, SpDefense, Speed}
        public StatName name;
        public float baseValue;
        public Stat(StatName n, float v)
        {
            name = n;
            baseValue = v;
        }
    }
}
