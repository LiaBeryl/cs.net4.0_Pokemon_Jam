﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    using LearnsetItem = KeyValuePair<int, Move>;//typing shortcut
    /// the base class for all actors in the game.  
    /// all other scripts in the root of the Actors namespace are there to support it
    /// </summary>
    abstract class Pokemon  //Lia
    {
        #region variables/proporties
        public int dexNum;
        public string name;
        public Ability ability; //not a feature as of yet strech
        public List<Stat> stats = new List<Stat>();
        public List<Move> moves = new List<Move>();
        public float level;
        public int xpTillNextLevel;
        public KeyValuePair<Type.Types, Type.Types> type;
        protected Learnset lvUpMoves = new Learnset();



        public string Name
        {
            get { return name; }
        }

        public string Ability
        {
            get { return ability.name; }
        }

        public string Type
        {
            get { return type.ToString(); }
        }

        public string Level
        {
            get { return level.ToString(); }
        }

        public string DexNum
        {
            get { return dexNum.ToString(); }
        }
        #endregion
        #region constructors
        public Pokemon(int dn)
        {
            dexNum = dn;
            level = 0f;
            for (int i = 0; i < 4; ++i)
            {
                moves.Add(new Moves.NullMove(this));
            }
            InitLearnset();
            ForceLevelUp();
        }

        public Pokemon(int dn, float lv)
        {
            dexNum = dn;
            level = 0f;
            InitLearnset();
            float l = (float)Math.Floor(lv);
            for (float F = 0f; F <= l; F += 1)
            {
                ForceLevelUp();
            }
        }
        #endregion
        #region init
        /// <summary>
        /// an abstarct version of the function that sets up the learnset table for a pokemon;
        /// basicly just makes it madatory that each pokemon setup a learnset.
        /// </summary>
        protected abstract void InitLearnset();

        /// <summary>
        /// sets up base stats with 6 ints (currently the only stats, needs update)
        /// </summary>
        /// <param name="hp"></param>
        /// <param name="attack"></param>
        /// <param name="defence"></param>
        /// <param name="spattack"></param>
        /// <param name="spdefence"></param>
        /// <param name="speed"></param>
        public void InitBaseStats(int hp, int attack, int defence, int spattack, int spdefence, int speed)
        {
            stats.Add(new Stat(Stat.StatName.HP, hp));
            stats.Add(new Stat(Stat.StatName.Attack, attack));
            stats.Add(new Stat(Stat.StatName.Defense, defence));
            stats.Add(new Stat(Stat.StatName.SpAttack, spattack));
            stats.Add(new Stat(Stat.StatName.SpDefense, spdefence));
            stats.Add(new Stat(Stat.StatName.Speed, speed));
        }
        #endregion
        #region accesors
        /// <summary>
        /// returns the stat of given type on that instance of a pokemon
        /// </summary>
        /// <param name="whatWeWant">the type of stat you are looking for</param>
        /// <returns>the Stat object as referance</returns>
        public Stat GetStat(Stat.StatName whatWeWant)
        {
            foreach (Stat s in stats)
            {
                if (s.name == whatWeWant)
                {
                    return s;
                }
            }
            throw new System.InvalidOperationException("Stat not found on pokemon, may not be initialized properly.");
        }

        /// <summary>
        /// gets one of the pokemon object's four moves
        /// </summary>
        /// <param name="moveIndex">the spot the move is at</param>
        /// <returns>the move at indicated spot</returns>
        public Move GetMove(int moveIndex)
        {
            if (moveIndex < 4 && moveIndex >= 0)
            {
                return moves.ElementAt(moveIndex);
            }
            else
            {
                throw new IndexOutOfRangeException("searhing for an invalid move index, pokemon can only know four moves");
            }
        }
        #endregion
        #region levelUp/newMoves
        /// <summary>
        /// levels up the assosiated pokemon and asks the player if they want to teach any of the new moves
        /// (for trained pokemon)
        /// </summary>
        protected void LevelUp()
        {
            level += 1;
            foreach (LearnsetItem k in lvUpMoves)
            {
                if (k.Key == (int)Math.Floor(level))
                {
                    AskLearnMove(k.Value);
                }
            }
            return;
        }

        /// <summary>
        /// levels up the assosiated pokemon and forces it to learn any new moves
        /// (for wild pokemon)
        /// </summary>
        protected void ForceLevelUp()
        {
            Random rand = new Random();
            level += 1;
            foreach (LearnsetItem k in lvUpMoves)
            {
                if (k.Key == (int)Math.Floor(level))
                {
                    LearnMove(rand.Next(0, 4), k.Value);
                }
            }
            return;
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// sends updates LearnMove event data in WindowManager and notifies GameLoop to handle said event
        /// </summary>
        /// <param name="newMove">the move that the player can choose to teach their active pokemon</param>
        private void AskLearnMove(Move newMove)
        {
            WindowManager.Instance.NewMoveData = newMove;
            WindowManager.Instance.newMove = true;
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// the final step in the teaching of a move.  this is where the old data gets removed, and the new is added.
        /// </summary>
        /// <param name="slotNum">the index for the move that is being replaced</param>
        /// <param name="newMove">the move that will go in the old move's slot</param>
        public void LearnMove(int slotNum, Move newMove)
        {
            if (slotNum >= 0 && slotNum < 4)
            {
                moves.RemoveAt(slotNum);
                moves.Insert(slotNum, newMove);
            }
        }
        #endregion
        #region attacking/damage
        /// <summary>
        /// DO NOT EXPLICITLY CALL!! IS TO BE CALLED IN MANAGER ONLY!!
        /// sends a passthrough to the chosen move to send it on to the BattleManager (BattleManager currently does not exist)
        /// </summary>
        /// <param name="slotNum">the index of the atack on the pokemon attacking</param>
        /// <param name="target">the pokemon that is on the recieving end of the attack</param>
        public void UseMove(int slotNum, Pokemon target)
        {
            GetMove(slotNum).SendAttack(target);
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// passthrough function for damage to this pokemon; in case contact or on-dammage events happen latter down the road.
        /// </summary>
        /// <param name="damage">the amount of hp to change on this pokemon</param>
        public void GotHit(int damage)
        {
            //space to add detail later
            ApplyHPChange(damage);
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// should probly be in the upcoming BattleManager and not in the individual pokemon.  
        /// but it's purpose is to update the hp value of a pokemon 
        /// and send a message to the combat log that such has happened.
        /// </summary>
        /// <param name="change"></param>
        protected void ApplyHPChange(int change)
        {
            if (change > 0)
            {
                //send damage msg
            }
            else if (change < 0)
            {
                //send heal msg
            }
            else if (change == 0)
            {
                //send noting happened msg
            }

        }
        #endregion
    }
}

