﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{   /// <summary>
    /// stores elemental type data.  currently just an enum.  in design will have efectivness calcs,
    /// and status immunity functions ingrained in the types...  but those arn't here yet.
    /// </summary>
    class Type  //Lia
    {
        public enum Types
        {
            Null,
            Normal,
            Fire,
            Fighting,
            Water,
            Flying,
            Grass,
            Poison,
            Electric,
            Ground,
            Psychic,
            Rock,
            Ice,
            Bug,
            Dragon,
            Ghost,
            Dark,
            Steel,
            Fairy
        }
    }
}
