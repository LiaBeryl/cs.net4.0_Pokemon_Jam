﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors
{
    /// <summary>
    /// the base class of all attacks in the game.  is used as a type field that can hold and use any attack class.
    /// there are no functions in this class that you need to call manualy.  ever.  don't try.
    /// </summary>
    abstract class Move  //Lia
    {
        #region variables/proporties
        public enum MoveStyle { physical, special, status }

        Random rand;
        Pokemon actor;
        bool STAB;
        protected Type.Types type;
        public float damageValue;
        protected MoveStyle moveStyle;
        protected string name;
        protected int pp;
        protected float accuracy;
        
        public string Name
        {
            get {return name; }
        }

        public string MoveType
        {
            get { return type.ToString(); }
        }

        public string Style 
        {
            get { return moveStyle.ToString(); }
        }

        public string Value
        {
            get { return damageValue.ToString()+" Power"; }
        }
        #endregion
        #region constructors
        protected Move(Pokemon a)
        {
            actor = a;
            if (actor.type.Key == type||actor.type.Value==type) { STAB = true; } else { STAB = false; }
            rand = new Random();
        }
        #endregion
        #region function declarations
        /// <summary>
        /// the shell to put the custom functions to be run 
        /// with any inividual attack that inherits from this
        /// </summary>
        /// <param name="target">the pokemon being attacked</param>
        public abstract void Attack(Pokemon target);
        #endregion
        #region attack flowOfControl functions
        /// <summary>
        /// DO NOT EXPLICITY CALL!!
        /// is called in Pokemon. is a pass through function that adds drainage of pp 
        /// (currently does not account for abilites like pressure).
        /// </summary>
        /// <param name="target">the pokemon that is being attacked</param>
        public void SendAttack(Pokemon target)
        {
            Attack(target);
            PPDown(1);
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// reduces pp of assosiated move and then floors it at zero.
        /// </summary>
        /// <param name="dropAmount">how much pp the move looses</param>
        private void PPDown(int dropAmount)
        {
            pp -= dropAmount;
            if (pp < 0) { pp = 0; }
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// puts all the relavent combat values into math soup and spits out the correct damage value for the situation
        /// (currently uses base stats rather than stat values as base stats are all that is existant curretly)
        /// </summary>
        /// <param name="target">the pokemon that is getting attacked</param>
        /// <param name="physOrSpec">the movestyle of the attack (status doesn't work yet, nor healing)</param>
        /// <returns>the damage to be applied to the attacked pokemon, 
        /// and yes int is correct.  you are not supposed to lose 0.3 hp, you are supposed to lose 1 hp.</returns>
        protected int DamageCalc(Pokemon target, MoveStyle physOrSpec)
        {
            //add status and healing streach
            if (damageValue > 0)
            {
                float randVal = rand.Next(85, 101) / 100f;
                if (physOrSpec == MoveStyle.physical)
                {
                    return (int)Math.Ceiling(((2f * actor.level / 5f + 2f) * damageValue * actor.GetStat(Stat.StatName.Attack).baseValue / target.GetStat(Stat.StatName.Defense).baseValue) / 50f + 2f * randVal * GetSTABMult());
                }
                else if (physOrSpec == MoveStyle.special)
                {
                    return (int)Math.Ceiling(((2f * actor.level / 5f + 2f) * damageValue * actor.GetStat(Stat.StatName.SpAttack).baseValue / target.GetStat(Stat.StatName.SpDefense).baseValue) / 50f + 2f * randVal * GetSTABMult());
                }
            }
            throw new InvalidOperationException("DamageCalc was called for a non-damaging move, what do you think you are doing?!");
        }

        /// <summary>
        /// DO NOT EXPLICITLY CALL!!
        /// returns the same type attack bonus damage multiplier if the move is on a pokemon that shares it's type
        /// </summary>
        /// <returns>multiplier for use with DamageCalc</returns>
        float GetSTABMult()
        {
            if (STAB)
            {
                return 1.5f;
            }
            else
            {
                return 1.0f;
            }
        }
        #endregion
    }
}
