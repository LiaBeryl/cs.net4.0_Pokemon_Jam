﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam.Actors.PokeDex
{
    
    using LearnsetItem = KeyValuePair<int, Move>;//typing shortcut
    using DualType = KeyValuePair<Type.Types, Type.Types>;
    /// <summary>
    /// dex #0 is here for testing purposes.  expect it to change.  alot.
    /// MissingNo will not be as you remember them by the end.
    /// </summary>
    class Dex0 : Pokemon //Lia
    {
        public Dex0(): base(0)                                          //I think you can understand all of this just by looking at it
        {                                                                           //you don't need me here ;-;
            InitBaseStats(33, 136, 0, 6, 6, 29);
            type = new DualType(Actors.Type.Types.Normal, Actors.Type.Types.Null);
            ability = new Actors.Abilities.NullAbility();
            name = "MissingNo";
        }

        public Dex0(float lv) : base(0, lv)
        {
            InitBaseStats(33, 136, 0, 6, 6, 29);
            LearnMove(0, new Moves.Tackle(this));
            type = new DualType(Actors.Type.Types.Normal, Actors.Type.Types.Null);
            ability = new Actors.Abilities.NullAbility();
            name = "MissingNo";
        }

        protected override void InitLearnset()
        {
            lvUpMoves.Add(new LearnsetItem(1, new Actors.Moves.WaterGun(this)));
            lvUpMoves.Add(new LearnsetItem(1, new Actors.Moves.WaterGun(this)));
            lvUpMoves.Add(new LearnsetItem(1, new Actors.Moves.SkyAttack(this)));
        }
    }
}
