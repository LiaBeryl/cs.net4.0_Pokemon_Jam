﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;
using betterExamGameJam;
using betterExamGameJam.Actors;
using betterExamGameJam.Actors.PokeDex;
using betterExamGameJam.Actors.Moves;

namespace betterExamGameJam
{
    /// <summary>
    /// Interaction logic for App.xaml (and also the core GameLoop)
    /// </summary>
    public partial class App : Application
    {
        private void App_OnStartup(object sender, StartupEventArgs e)
        {
            BuildWorld(new Dex0());
            MainWindow mainWindow = new MainWindow();
            mainWindow.ShowDialog();
            GameLoop();
        }

        void BuildWorld(Pokemon starter)
        {
            Party.Instance.AddToParty(starter); // get starter
        }

        void GameLoop()
        {
            while (true)
            {
                if (WindowManager.Instance.newMove)
                {
                    WindowManager.Instance.cachedPartyMember = Party.Instance.GetActivePartyMember();
                    Window1 secondaryWindow = new Window1();
                    secondaryWindow.ShowDialog();
                    WindowManager.Instance.newMove = false;
                }
            }
        }
    }
}
