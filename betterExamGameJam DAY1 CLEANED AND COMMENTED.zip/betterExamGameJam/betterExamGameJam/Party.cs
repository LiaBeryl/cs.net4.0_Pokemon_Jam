﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam
{   /// <summary>
    /// manager class for handling the player's party and active pokemon
    /// </summary>
    class Party  //Lia
    {
        public static Party Instance;
        List<Actors.Pokemon> party = new List<Actors.Pokemon>();
        int activePartyIndex;

        static Party()
        {
            Instance = new Party();
            Instance.activePartyIndex = 0;
        }

        public Actors.Pokemon GetActivePartyMember()
        {
            return Instance.party.ElementAt(Instance.activePartyIndex);
        }

        /// <summary>
        /// cycles active partymember
        /// </summary>
        public void NextPartyMember()
        {
            if (activePartyIndex < Instance.party.Count)
            {
                activePartyIndex += 1;
            }else
            {
                activePartyIndex = 0;
            }
        }

        /// <summary>
        /// currently there is no limit to how many pokemon you can have in your party.  this needs to change
        /// </summary>
        /// <param name="target">the pokemon you are trying to add to your party</param>
        public void AddToParty(Actors.Pokemon target)
        {
            party.Add(target);
        }
    }
}
