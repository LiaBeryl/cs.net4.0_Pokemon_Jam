﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace betterExamGameJam
{   /// <summary>
    /// a manager class to hold all the bidable proporties for use with windows,
    /// and to store some of the non-window-specific logic
    /// </summary>
    class WindowManager  //Lia
    {
        public static WindowManager Instance;
        public bool newMove;
        public Actors.Move newMoveData;
        public Actors.Pokemon cachedPartyMember;

        static WindowManager()
        {
            Instance = new WindowManager();
        }

        public Actors.Pokemon PartyMember
        {
            get { return Party.Instance.GetActivePartyMember(); }
        }

        public Actors.Move NewMoveData
        {
            get{ return newMoveData; }
            set { newMoveData = value; }
        }

        public Actors.Move GetMove0
        {
            get { return PartyMember.GetMove(0); }
        }

        public Actors.Move GetMove1
        {
            get {return PartyMember.GetMove(1); }
        }

        public Actors.Move GetMove2
        {
            get { return PartyMember.GetMove(2); }
        }

        public Actors.Move GetMove3
        {
            get { return PartyMember.GetMove(3); }
        }
    }
}
